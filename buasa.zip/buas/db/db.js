import { Sequelize, DataTypes } from "sequelize";

const sequelize = new Sequelize('dataa_siswaa', 'root', '', {
    host: 'localhost',
    dialect:'mysql',
});

export { sequelize, DataTypes };