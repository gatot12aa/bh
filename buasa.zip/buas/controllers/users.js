import User from "../models/user.js";

const getlogin = (req,res) => {
    res.render("login",{user:req.session.user || ""});
}

const postlogin =  (req,res) => {
    const {email, password} = req.body;
    User.findOne({where : {email : email}}).then(result => {
        if (!result){
            res.redirect("/login");
        }else if(result.password != password){
            res.redirect("/login");
        }else{
            req.session.user = result;
            res.redirect("/");
        }
    })
}


const logout = (req, res) => {
    req.session.destroy();
    res.redirect("/");
}

export {
    getlogin,
    postlogin,
    logout
}