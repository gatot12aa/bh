import { sequelize, DataTypes } from "../db/db.js";

const Absensi = sequelize.define("absensi", {
    nama: DataTypes.STRING,
    nim: DataTypes.STRING,
    mapel: DataTypes.STRING
   
});

export default Absensi;
